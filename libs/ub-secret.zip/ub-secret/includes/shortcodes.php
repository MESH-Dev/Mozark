<?php


/*____________________________________________

LAYOUTS
______________________________________________*/



/*-------------------------------------
 Row 
--------------------------------------*/
if (!function_exists('row')) 
{
  function row($atts, $content = null)
  {
    extract(shortcode_atts(array( "customclass" => '',"fx" => '','id' => ''), $atts));
    if($fx !=''){ $colfx ='animated" data-fx="'.$fx.'"';} else { $colfx='"'; }
    if($id !=''){ $rowid ='id="'.$id.'"';} else { $rowid=''; }

    $html = "\n".'<div '.$rowid.' class="row '.$customclass.' '.$colfx.'>'.do_shortcode($content).'</div>'."\n";

     return $html;
  }
  add_shortcode('row', 'row');
} 

/*-------------------------------------
 Column 
--------------------------------------*/
if (!function_exists('column')) 
{
  function column($atts, $content = null)
  {
    extract(shortcode_atts(array("span" => "4","mobile"=>"","customclass"=>"", "fx" => '','id' => ''), $atts));
   
    if($mobile !=''){ $mob ='col-xs-'.$mobile.'';} else { $mob=''; }
    if($fx !=''){ $colfx ='animated" data-fx="'.$fx.'"';} else { $colfx='"'; }
    if($id !=''){ $rowid ='id="'.$id.'"';} else { $rowid=''; }

    //Return content 
    $html = '<article '.$rowid.' class="col-md-'.$span.'  col-lg-'.$span.' '.$mob.' '.$customclass.' '.$colfx.'>'.do_shortcode($content).'</article>';
    return $html;
  }
  add_shortcode('column', 'column');
}  





/*-------------------------------------
 Column 
--------------------------------------*/
if (!function_exists('about_block')) 
{
  function about_block($atts, $content = null)
  {
    extract(shortcode_atts(array("width" => "4","mobile"=>"","customclass"=>"", "fx" => '','heading' => ''), $atts));
   
    if($mobile !=''){ $mob ='col-xs-'.$mobile.'';} else { $mob=''; }
    if($fx !=''){ $colfx ='animated" data-fx="'.$fx.'"';} else { $colfx='"'; }


    //Return content 
    $html = '<article  class="about-content text-left col-md-'.$width.'  col-lg-'.$width.' '.$mob.' '.$customclass.' '.$colfx.'>
    <h4>'.$heading.'</h4><p>'.do_shortcode($content).'</p></article>';
    return $html;
  }
  add_shortcode('about_block', 'about_block');
}  

/*____________________________________________

Modules
______________________________________________*/



/*-------------------------------------
Adddress Box
--------------------------------------*/

if (!function_exists('address_block')) 
{
  function address_block($atts, $content = null)
  {
    extract(shortcode_atts(array("phone"=>"","email"=>""), $atts));
    $html = '<div class="contact-address">
                  <h1 class="color-light">'.$phone.'</h1>
                  <a href="mailto:'.$email.'"><h2>'.$email.'</h2></a>
                  <p>'.$content.'</p>
             </div>';
    
    return $html;
  }
  add_shortcode('address_block', 'address_block');
} 

             








/*-------------------------------------
Portfolio Block
--------------------------------------*/
if (!function_exists('portfolio')) 
{
  function portfolio($atts, $content = null)
  {
        wp_enqueue_script('shuffle');
        wp_enqueue_script('shuffle-init');



    extract(shortcode_atts(array( "grid"=>"4","categories" => ''), $atts));
    $html = '';

    if($categories !='')
    {
      $args = array(
                  'post_type' => 'portfolio_item', 
                  'orderby' => 'date', 
                  'order' => 'ASC',
                  'posts_per_page' => 300,
                  'paged'=>false,
                  'portfolio_category' => $categories
                  );
    }
    else
    {
      $args = array(
                  'post_type' => 'portfolio_item', 
                  'orderby' => 'date', 
                  'order' => 'ASC',
                  'posts_per_page' => 300,
                  'paged'=>false,
                  );      
    }
    


    //Lightbox  video,image
    //Ajax - Video,Slider
    //Absolute Page

    //Parent
    //$html .='<div class="works-gallery portfolio-blocks '.$width_class.'  text-center">';

    /*-----Filters-------
    --------------------------*/
 
    $html .='
         <div class="row">
          <div class="col-md-12">
          <div class="portfolio-filter-nav text-center" >
            <ul id="filter">
              <li><a href="#" class="filter active" data-group="all">'.__('All','secretlang').'</a></li>';
              if($categories !='')
              {
                    $cate_list = explode(",", $categories);
                    foreach ($cate_list as $cate) 
                    {
                      $html .= '<li><a href="#" class=" filter" data-group="'.$cate.'">'.$cate.'</a>&nbsp;&nbsp;</li>';
                    }
              }
              else
              {
                   global $post;
                   $list_categories = get_categories(array('type' => 'portfolio_item', 'taxonomy' => 'portfolio_category'));
                   foreach($list_categories as $category): 
                         $categoryClass = strtolower($category->slug);  
                          $html .= '<li><a href="#" class=" filter" data-group="'.$categoryClass.'">'.$category->name.'</a></li>';
                   endforeach;                        
              }  
    $html .='</ul>
          </div>
        </div>
       </div> '; 
    $html .='';

    /*-----Grid------------------------
    ----------------------*/
     $html .='<div class="row portfolio ">
    <div id="grid" class="col-md-12">';



  $loop = new WP_Query($args); 
  while ( $loop->have_posts() ) : $loop->the_post(); 
  //All the meta options
  $cate = wp_get_post_terms($post->ID, $taxonomy = 'portfolio_category'); 
  $exp_mode    =  get_post_meta($post->ID,'secret_ub_port_mode',true );
   
  if($cate)
  {
        //Multiple categories
        $arr_cnt = count($cate) - 1;
        $slug_arr = '';
        $class_arr = '';
        $filter = "[\"all\"";
        for($i=0;$i<=$arr_cnt;$i++)
        {
          if($i >= '1'): $slug_arr .=","; endif;
          $slug_arr .= strtolower($cate[$i]->name);
          $class_arr .= strtolower($cate[$i]->slug)." ";
          $fill_arr = ",\"".strtolower($cate[$i]->slug)."\"";
        }
        $close_fl = ']';


      switch($exp_mode)
      {
        case 'lightbox':
      $lb_image    =  get_post_meta($post->ID,'secret_port_lightbox_image',true );
      $html .= "<!-- Portfolio Item One Light box -->
              <div class='shuf-item portfolio-item' data-groups='".$filter.$fill_arr.$close_fl."'>";
              if(has_post_thumbnail()): 
                  $thumbnail_img = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), '', true, '');
                  $html .= '<img src="'.$thumbnail_img[0].'"  alt="'.get_the_title().'" class="img-responsive" />';
                     
              endif;

      if($lb_image !=''): $show_lb = $lb_image; else: $show_lb =  $thumbnail_img[0]; endif; 
      $html .= '<a href="'.$show_lb.'" class="venobox portfolio-item-mask" data-gall="portfolio-gallery-1">
                  <div class="vertical-align text-center">
                    <h3 class="text-center">'.get_the_title().'</h3>
                    <h5 class="text-center">'.$slug_arr.'</h5>
                  </div>
                </a>
              </div>';


        break;

        case 'project_page':
          $link_blank    =  get_post_meta($post->ID,'secret_port_open_tab',true );
          if($link_blank == 'on'): $ltarget="_blank"; else: $ltarget ="_self"; endif;
          $html .= "<!-- Proj Page -->
                  <div class='shuf-item portfolio-item' data-groups='".$filter.$fill_arr.$close_fl."'>";
                  if(has_post_thumbnail()): 
                      $thumbnail_img = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), '', true, '');
                      $html .= '<img src="'.$thumbnail_img[0].'"  alt="'.get_the_title().'" class="img-responsive" />';
                  endif;
          $html .= '<a class="portfolio-item-mask" href="'.get_permalink().'" target="'.$ltarget.'">
                      <div class="vertical-align ">
                        <h3 class="text-center">'.get_the_title().'</h3>
                        <h5 class="text-center">'.$slug_arr.'</h5>
                      </div>
                    </a>
                  </div>';
          break;

        default:
          $html .= "<!-- Proj Page -->
                  <div class='shuf-item portfolio-item' data-groups='".$filter.$fill_arr.$close_fl."'>";
                  if(has_post_thumbnail()): 
                      $thumbnail_img = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), '', true, '');
                      $html .= '<img src="'.$thumbnail_img[0].'"  alt="'.get_the_title().'" class="img-responsive" />';
                  endif;
          $html .= '<a class="portfolio-item-mask" href="'.get_permalink().'" target="_blank">
                      <div class="vertical-align">
                        <h3 class="text-center">'.get_the_title().'</h3>
                        <h5 class="text-center">'.$slug_arr.'</h5>
                      </div>
                    </a>
                  </div>';
        break;
      }









    } //Category multi support

    endwhile;


    $html .='</div></div>';

    /*-----Grid ends------*/



    //Parent close
    $html .='
    ';

    return $html;
  }
  add_shortcode('portfolio', 'portfolio');
} 







/*-------------------------------------
Team Members Block
--------------------------------------*/

if (!function_exists('teamwrap')) 
{
  function teamwrap($atts, $content = null)
  {
    $html = '<div class="owl-carousel team-slider">
    '.do_shortcode($content).'
    </div>';
    return $html;
  }
  add_shortcode('teamwrap', 'teamwrap');
}  

/*team_member*/

if (!function_exists('team_member')) 
{
  function team_member($atts, $content = null)
  {
    extract(shortcode_atts(array("name" => "","designation"=>"","photo"=>"","twitter"=>"", "facebook" => '',"plus" => '',"email" => ''), $atts));
    

        $html =  '<div class="team-item  text-center">
                <div class="team-member grey-scale-img">
                  <img src="'.$photo.'" class="img-responsive" alt="'.$name.'">
                  <div class="team-member-social-icons">';
                    
                    if($facebook !=''):  $html .= '<a href="www.facebook.com/'.$facebook.'" class="social-icon"><img src="'.get_template_directory_uri().'/images/team/facebook.png" alt="facebook-icon"></a>&nbsp;&nbsp;'; endif;
                    if($twitter !=''):  $html .= '<a href="www.twitter.com/'.$twitter.'" class="social-icon"><img src="'.get_template_directory_uri().'/images/team/twitter.png" alt="twitter-icon"></a>&nbsp;&nbsp;'; endif;
                    if($plus !=''):  $html .= '<a href="plus.google.com/'.$plus.'" class="social-icon"><img src="'.get_template_directory_uri().'/images/team/googleplus.png" alt="googleplus-icon"></a>&nbsp;&nbsp;'; endif;
                    if($email !=''):  $html .= '<a href="mailto:'.$email.'" class="social-icon"><img src="'.get_template_directory_uri().'/images/team/mail.png" alt="mail-icon"></a>'; endif;
                  
        $html .='</div>
                </div>  
                <div class="team-member-name">
                  <h4>'.$name.'</h4>
                  <p>'.$designation.'</p> 
                </div>
              </div> ';

    return $html;
  }
  add_shortcode('team_member', 'team_member');
} 



/*-------------------------------------
Service
--------------------------------------*/
if (!function_exists('service_wrap')) 
{
  function services_wrap($atts, $content = null)
  {
    $html = '<div class="owl-carousel services-slider">
    '.do_shortcode($content).'
    </div>';
    return $html;
  }
  add_shortcode('services_wrap', 'services_wrap');
}  

if (!function_exists('service')) 
{
  function service($atts, $content = null)
  {
     extract(shortcode_atts(array( "title" => '',"icon"=>"","link"=>"","label"=>"","fx"=>""), $atts));

     if($fx !=''){ $colfx ='animated" data-fx="'.$fx.'"';} else { $colfx='"'; }
     
      $html = "\n".'<div class="services-column text-center '.$colfx.'>
                  <img src="'.$icon.'" alt="'.$title.'">
                  <h4>'.$title.'</h4>
                  <p>'.$content.'</p>
                  <div><a href="'.$link.'" class="button-01">'.$label.'</a></div>
                </div>'."\n";
     


     return $html;
  }
  add_shortcode('service', 'service');
} 

/*-------------------------------------
Iamge Slider
--------------------------------------*/
if (!function_exists('slider_wrap')) 
{
  function slider_wrap($atts, $content = null)
  {
    $html = '<div class="owl-carousel single-project-slider">
    '.do_shortcode($content).'
    </div>';
    return $html;
  }
  add_shortcode('slider_wrap', 'slider_wrap');
}  

if (!function_exists('slide')) 
{
  function slide($atts, $content = null)
  {
     extract(shortcode_atts(array( "img" => ''), $atts));
     $html = "\n".'<img src="'.$img.'" class="img-responsive" alt="img">'."\n";     
     return $html;
  }
  add_shortcode('slide', 'slide');
} 
       
                              

                  
/*-------------------------------------
Price Table
--------------------------------------*/
if (!function_exists('price_table')) 
{
  function price_table($atts, $content = null)
  {
     extract(shortcode_atts(array( "title" => '',"width" => '3',"price"=>"","basis"=>"","link"=>"#","label"=>"Order Now","featured"=>"","fx"=>''), $atts));
     if($fx !=''){ $colfx ='animated" data-fx="'.$fx.'"';} else { $colfx='"'; }

     $html = '              
              <div class="col-md-'.$width.' col-sm-6 text-center '.$colfx.'>
                <div class="pricing-column">
                  <div class="pricing-head">';

                   if($featured != ''):
                    $html .= '<img src="'.get_stylesheet_directory_uri().'/images/star.png" alt="star">';
                   endif;
                   $html .= ' <h5>'.$title.'</h5>';
                   if($featured != ''):
                    $html .= '<img src="'.get_stylesheet_directory_uri().'/images/star.png" alt="star">';
                   endif;

                    $html .= '<h1>'.$price.'</h1>
                    <p>'.$basis.'</p>
                  </div>
                  <svg class="sland" viewBox="0 0 100 100" preserveAspectRatio="none">
                    <path d="M0 0 L50 100 L100 0 Z"/>
                  </svg>
                  <div class="pricing-features">
                    <ul>'.do_shortcode($content).'</ul>
                  </div>
                  <div><a href="'.$link.'" class="button-02">'.$label.'</a></div>
                </div>  
              </div>';


     return $html;
  }
  add_shortcode('price_table', 'price_table');
} 
/*Spec*/
if (!function_exists('spec')) 
{
  function spec($atts, $content = null)
  {
    $html = '<li>'.$content.'</li>';
    return $html;
  }
  add_shortcode('spec', 'spec');
}  


/*-------------------------------------
Testimonial
--------------------------------------*/

if (!function_exists('testimonial_wrapper')) 
{
  function testimonial_wrapper($atts, $content = null)
  {
    $html = '<div class="testimonial text-center"><section class="owl-carousel testimonial-owl">
    '.do_shortcode($content).'
    </section></div>';
    return $html;
  }
  add_shortcode('testimonial_wrapper', 'testimonial_wrapper');
}  
/*--testimonial--*/
if (!function_exists('testimonial')) 
{
  function testimonial($atts, $content = null)
  {     
    extract(shortcode_atts(array( "designation" => '',"name"=>''), $atts));
    $html = '<div>
              <p>"</p>
              <h1>'.$content.'</h1>
              <h3>'.$name.'</h3>
              <h5>'.$designation.'</h5>
            </div>';
    return $html;
  }
  add_shortcode('testimonial', 'testimonial');
}  




/*-------------------------------------
Contact Form
--------------------------------------*/

if (!function_exists('contact_form')) 
{


  function contact_form($atts, $content = null)
  {
      global $secret_thm;
    wp_enqueue_script('form-validation');

   $html = '

            <div class="row">
              <div class="col-md-offset-3 col-md-6 col-sm-offset-3 col-sm-6">
                          <div id="fname" class="alert alert-error error text-center">
                              <p>'.esc_html($secret_thm['label_name_error']).'</p>
                          </div>
                          <div id="femail" class="alert alert-error error text-center">
                              <p>'.esc_html($secret_thm['label_email_error']).'</p>
                          </div>
                          <div id="fsubject" class="alert alert-error error text-center">
                              <p>'.esc_html($secret_thm['label_subject_error']).'</p>
                          </div>
                          <div id="fmessage" class="alert alert-error error text-center">
                              <p>'.esc_html($secret_thm['label_message_error']).'</p>
                          </div>   
                       <div class="theme-error success alert alert-error error text-center">
                            '.esc_html($secret_thm['msg_success']).'
                        </div>
                        <div class="theme-error failure alert alert-error error text-center">
                            '.esc_html($secret_thm['msg_fail']).'
                        </div>  

                <form name="myform" id="contactform" action="'.plugins_url(). '/ub-secret/sendmail.php" enctype="multipart/form-data" method="post">
                  <div class="row">
                    <div class="contact-form">
                      <input type="text" id="name" placeholder="'.esc_html($secret_thm['label_name']).'" name="name">
                      <input type="text" id="email" placeholder="'.esc_html($secret_thm['label_email']).'" name="email">
                      <input type="text" id="subject" placeholder="'.esc_html($secret_thm['label_subject']).'" name="subject">
                      <label for="message">'.esc_html($secret_thm['label_message']).'</label>
                      <textarea id="message" name="message"></textarea>
                      <button type="submit" name="submit" id="submit">'.esc_html($secret_thm['label_sendmsg']).'</button>
                    </div>  
                  </div>
                </form>
              </div>
            </div>';


    return $html;
  }
  add_shortcode('contact_form', 'contact_form');
} 



/*______________________________________________________________________________________

Titles
________________________________________________________________________________________*/

/*-------------------------------------
Buttons
--------------------------------------*/

/*-------------------------------------
TYpe Button 
--------------------------------------*/
if (!function_exists('thm_button')) 
{
  function thm_button($atts, $content = null)
  {
     extract(shortcode_atts(array( "label" => '',"link"=>''), $atts));

      $html = "\n".'<a class="button-01" href="'.$link.'">'.$label.'</a>'."\n";
     
  }
  add_shortcode('thm_button', 'thm_button');
} 







/*____________________________________________________
SPECIALS
______________________________________________________*/

/*-------------------------------------
Home Carousel
--------------------------------------*/

if (!function_exists('hc_wrapper')) 
{
  function hc_wrapper($atts, $content = null)
  {
        extract(shortcode_atts(array( "link" => '#'), $atts));
    $html = '<div class="home-bg-img-02 full-height text-center">
            <!-- Home slider : starts -->
            <div class="owl-carousel home-slider vertical-align">
    '.do_shortcode($content).'
    </div>
            <!-- Home slider : ends -->
            
            <div class="down-scroll-position">
              <a href="'.$link.'" class="scroll-link">
                  <img class="d_arrw" src="'.get_template_directory_uri().'/images/down_arrow.png" alt="star">
              </a>
            </div>
          </div>';
    return $html;
  }
  add_shortcode('hc_wrapper', 'hc_wrapper');
}  
/*--testimonial--*/
if (!function_exists('hc_item_s1')) 
{
  function hc_item_s1($atts, $content = null)
  {     
    extract(shortcode_atts(array( "title" => '',"sub"=>'',"color"=>"#FFF","style"=>"1"), $atts));

      if($style == '1'):
      $html = '<div class="home-title home-slider-item01">
                <img src="'.get_template_directory_uri().'/images/home/star.png" alt="star">
                <h2 style="color:'.$color.'">'.$sub.'</h2>
                <img src="'.get_template_directory_uri().'/images/home/star.png" alt="star">
                <h1 style="color:'.$color.'">'.$title.'</h1>
                <img src="'.get_template_directory_uri().'/images/home/zigzag_line.png" alt="image">
                <p style="color:'.$color.'">'.$content.'</p>
              </div>';
     else:
     $html = '<div class="home-title home-slider-item02 color-light">
                <h3 style="color:'.$color.'">'.$sub.'</h3>
                <h1 style="color:'.$color.'">'.$title.'</h1>
                <img src="'.get_template_directory_uri().'/images/home/star.png" alt="star">
                <h2 style="color:'.$color.'">'.$content.'</h2>
                <img src="'.get_template_directory_uri().'/images/home/star.png" alt="star">
              </div>';          
    endif;



    return $html;
  }
  add_shortcode('hc_item_s1', 'hc_item_s1');
}  


/*-------------------------------------
Home Slider
--------------------------------------*/

if (!function_exists('home_slider')) 
{
  function home_slider($atts, $content = null)
  {
    extract(shortcode_atts(array( "link" => '#'), $atts));
    $html = '<section id="sec-hs-carousel-home" class="owl-carousel home-slider">
    '.do_shortcode($content).'
    </section>				
    ';
    return $html;
  }
  add_shortcode('home_slider', 'home_slider');
}  
/*--testimonial--*/
if (!function_exists('slider_item')) 
{
  function slider_item($atts, $content = null)
  {     
    
    extract(shortcode_atts(array( "bg_image" => '',"style" => '1',"title" => '',"sub"=>'',"color"=>"#FFF","link"=>"#",'ovl'=>'rgba(0,0,0,0.5)'), $atts));
    
    if($style == '1'):
    $html = '<section class="inner-section">
					<div class="full-height" style="background:url('.$bg_image.'); background-size:cover;">
					<div class="full-height" style="background:'.$ovl.';">
						<div class="home-title home-slider-item01 color-light vertical-align">
							<img src="'.get_template_directory_uri().'/images/home/star.png" alt="star">
							<h2 style="color:'.$color.'">'.$title.'</h2>
							<img src="'.get_template_directory_uri().'/images/home/star.png" alt="star">
							<h1 style="color:'.$color.'">'.$sub.'</h1>
							<img src="'.get_template_directory_uri().'/images/home/zigzag_line.png" alt="image">
							<p style="color:'.$color.'">'.$content.'</p>
						</div>
						<div class="down-scroll-position">
							<a href="'.$link.'" class="scroll">
                  <img class="d_arrw" src="'.get_template_directory_uri().'/images/down_arrow.png" alt="star">
							</a>
						</div>
						</div>
					</div>
				</section>';
     else:
     	$html = '<section class="inner-section">
					<div class="full-height" style="background:url('.$bg_image.'); background-size:cover;">
					<div class="full-height" style="background:'.$ovl.';">
						<div class="home-title home-slider-item02 color-light vertical-align">
							<h3>'.$sub.'</h3>
							<h1>'.$title.'</h1>
							<img src="'.get_template_directory_uri().'/images/home/star.png" alt="star">
							<h2>'.$content.'</h2>
							<img src="'.get_template_directory_uri().'/images/home/star.png" alt="star">
						</div>
						<div class="down-scroll-position">
							<a href="'.$link.'" class="scroll">
                  <img class="d_arrw" src="'.get_template_directory_uri().'/images/down_arrow.png" alt="star">
							</a>
						</div>
						</div>
					</div>
				</section>';				
     endif;


    return $html;
  }
  add_shortcode('slider_item', 'slider_item');
}  






/*____________________________________________

HOOKS
______________________________________________*/

/*-------------------------------------
Fixing Unwanted P tags
--------------------------------------*/

add_filter("the_content", "the_content_filter");
function the_content_filter($content) 
{
  // array of custom shortcodes requiring the fix
  $block = join("|",array("row",
"column",
"about_block",
"address_block",
"portfolio",
"teamwrap",
"team_member",
"services_wrap",
"service",
"slider_wrap",
"slide",
"price_table",
"spec",
"testimonial_wrapper",
"testimonial",
"contact_form",
"thm_button",
"hc_wrapper",
"hc_item_s1",
"home_slider",
"slider_item",)); 
  // opening tag
  $rep = preg_replace("/(<p>)?\[($block)(\s[^\]]+)?\](<\/p>|<br \/>)?/","[$2$3]",$content);
  // closing tag
  $rep = preg_replace("/(<p>)?\[\/($block)](<\/p>|<br \/>)?/","[/$2]",$rep);
  return $rep;
}


