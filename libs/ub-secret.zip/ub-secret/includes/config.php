<?php
/**
 * Define the shortcode parameters
 *
 * @package ZillaShortcodes
 * @since 1.0
 */




/* row Config --- */
// customclass
// bgimage
$zilla_shortcodes['row'] = array(
	'title' => __('row', 'secretlang'),
	'id' => 'secretlang-row-shortcode',
	'template' => '[row {{attributes}}] {{content}} [/row]',
	'params' => array(
		'id' => array(
			'std' => '',
			'type' => 'text',
			'label' => __('HTML ID', 'secretlang'),
			'desc' => __('Optional', 'secretlang')
		),
		'customclass' => array(
			'std' => '',
			'type' => 'text',
			'label' => __('Additional CSS Classes', 'secretlang'),
			'desc' => __('Optional', 'secretlang')
		),
		'fx' => array(
				'type' => 'select',
				'label' => __('Apparance Animation', 'secretlang'),
				'desc' => __('', 'secretlang'),
				'options' => array(
					'' => 'None',
					'bounce' => 'bounce',
					'flash' => 'flash',
					'pulse' => 'pulse',
					'shake' => 'shake',
					'swing' => 'swing',
					'tada' => 'tada',
					'wobble' => 'wobble',
					'bounceIn' => 'bounceIn',
					'bounceInDown' => 'bounceInDown',
					'bounceInLeft' => 'bounceInLeft',
					'bounceInRight' => 'bounceInRight',
					'bounceInUp' => 'bounceInUp',
					'bounceOut' => 'bounceOut',
					'bounceOutDown' => 'bounceOutDown',
					'bounceOutLeft' => 'bounceOutLeft',
					'bounceOutRight' => 'bounceOutRight',
					'bounceOutUp' => 'bounceOutUp',
					'fadeIn' => 'fadeIn',
					'fadeInDown' => 'fadeInDown',
					'fadeInDownBig' => 'fadeInDownBig',
					'fadeInLeft' => 'fadeInLeft',
					'fadeInLeftBig' => 'fadeInLeftBig',
					'fadeInRight' => 'fadeInRight',
					'fadeInRightBig' => 'fadeInRightBig',
					'fadeInUp' => 'fadeInUp',
					'fadeInUpBig' => 'fadeInUpBig',
					'flip' => 'flip',
					'flipInX' => 'flipInX',
					'flipInY' => 'flipInY',				
					'lightSpeedIn' => 'lightSpeedIn',
					'rotateIn' => 'rotateIn',
					'rotateInDownLeft' => 'rotateInDownLeft',
					'rotateInDownRight' => 'rotateInDownRight',
					'rotateInUpLeft' => 'rotateInUpLeft',
					'rotateInUpRight' => 'rotateInUpRight',
					'slideInDown' => 'slideInDown',
					'slideInLeft' => 'slideInLeft',
					'slideInRight' => 'slideInRight'
				)
         ),				
		'content' => array(
			'std' => 'Contents/Shortcodes',
			'type' => 'textarea',
			'label' => __('Section Content', 'secretlang'),
			'desc' => __('Its a wrapper. Add more conetnts manually', 'secretlang'),
		)

	)
);


/* Column Config --- */
// span
// mobile
// customclass
// id
$zilla_shortcodes['column'] = array(
	'title' => __('column', 'secretlang'),
	'id' => 'secretlang-column-shortcode',
	'template' => '[column {{attributes}}] {{content}} [/column]',
	'params' => array(
		'span' => array(
			'type' => 'select',
			'label' => __('Columns', 'secretlang'),
			'desc' => __('Bootstrap Columns', 'secretlang'),
			'options' => array(
				'6' => '6',
				'1' => '1',
				'2' => '3',
				'3' => '3',
				'4' => '4',
				'5' => '5',
				'7' => '7',
				'8' => '8',
				'9' => '9',
				'10' => '10',
				'11' => '11',
				'12' => '12',															
			)
		),
		'mobile' => array(
			'type' => 'select',
			'label' => __('Columns', 'secretlang'),
			'desc' => __('Bootstrap Columns', 'secretlang'),
			'options' => array(
				'12' => '12',
				'1' => '1',
				'2' => '3',
				'3' => '3',
				'4' => '4',
				'5' => '5',
				'6' => '6',
				'7' => '7',
				'8' => '8',
				'9' => '9',
				'10' => '10',
				'11' => '11',
																			
			)
		),					
		'id' => array(
			'std' => '',
			'type' => 'text',
			'label' => __('HTML ID', 'secretlang'),
			'desc' => __('Optional', 'secretlang')
		),
		'customclass' => array(
			'std' => '',
			'type' => 'text',
			'label' => __('Additional CSS Classes', 'secretlang'),
			'desc' => __('Optional', 'secretlang')
		),
		'fx' => array(
				'type' => 'select',
				'label' => __('Apparance Animation', 'secretlang'),
				'desc' => __('', 'secretlang'),
				'options' => array(
					'' => 'None',
					'bounce' => 'bounce',
					'flash' => 'flash',
					'pulse' => 'pulse',
					'shake' => 'shake',
					'swing' => 'swing',
					'tada' => 'tada',
					'wobble' => 'wobble',
					'bounceIn' => 'bounceIn',
					'bounceInDown' => 'bounceInDown',
					'bounceInLeft' => 'bounceInLeft',
					'bounceInRight' => 'bounceInRight',
					'bounceInUp' => 'bounceInUp',
					'bounceOut' => 'bounceOut',
					'bounceOutDown' => 'bounceOutDown',
					'bounceOutLeft' => 'bounceOutLeft',
					'bounceOutRight' => 'bounceOutRight',
					'bounceOutUp' => 'bounceOutUp',
					'fadeIn' => 'fadeIn',
					'fadeInDown' => 'fadeInDown',
					'fadeInDownBig' => 'fadeInDownBig',
					'fadeInLeft' => 'fadeInLeft',
					'fadeInLeftBig' => 'fadeInLeftBig',
					'fadeInRight' => 'fadeInRight',
					'fadeInRightBig' => 'fadeInRightBig',
					'fadeInUp' => 'fadeInUp',
					'fadeInUpBig' => 'fadeInUpBig',
					'flip' => 'flip',
					'flipInX' => 'flipInX',
					'flipInY' => 'flipInY',				
					'lightSpeedIn' => 'lightSpeedIn',
					'rotateIn' => 'rotateIn',
					'rotateInDownLeft' => 'rotateInDownLeft',
					'rotateInDownRight' => 'rotateInDownRight',
					'rotateInUpLeft' => 'rotateInUpLeft',
					'rotateInUpRight' => 'rotateInUpRight',
					'slideInDown' => 'slideInDown',
					'slideInLeft' => 'slideInLeft',
					'slideInRight' => 'slideInRight'
				)
         ),					
		'content' => array(
			'std' => 'Contents/Shortcodes',
			'type' => 'textarea',
			'label' => __('Column Content/ Use Wp Editor', 'secretlang'),
			'desc' => __('', 'secretlang'),
		)

	)
);
/* About Block Config --- */
// span
// mobile
// customclass
// id
$zilla_shortcodes['about_block'] = array(
	'title' => __('about_block', 'secretlang'),
	'id' => 'secretlang-about_block-shortcode',
	'template' => '[about_block {{attributes}}] {{content}} [/about_block]',
	'params' => array(
		'width' => array(
			'type' => 'select',
			'label' => __('Columns', 'secretlang'),
			'desc' => __('Bootstrap Columns', 'secretlang'),
			'options' => array(
				'6' => '6',
				'1' => '1',
				'2' => '3',
				'3' => '3',
				'4' => '4',
				'5' => '5',
				'7' => '7',
				'8' => '8',
				'9' => '9',
				'10' => '10',
				'11' => '11',
				'12' => '12',															
			)
		),				
		'customclass' => array(
			'std' => '',
			'type' => 'text',
			'label' => __('Additional CSS Classes', 'secretlang'),
			'desc' => __('Optional', 'secretlang')
		),
		'fx' => array(
				'type' => 'select',
				'label' => __('Apparance Animation', 'secretlang'),
				'desc' => __('', 'secretlang'),
				'options' => array(
					'' => 'None',
					'bounce' => 'bounce',
					'flash' => 'flash',
					'pulse' => 'pulse',
					'shake' => 'shake',
					'swing' => 'swing',
					'tada' => 'tada',
					'wobble' => 'wobble',
					'bounceIn' => 'bounceIn',
					'bounceInDown' => 'bounceInDown',
					'bounceInLeft' => 'bounceInLeft',
					'bounceInRight' => 'bounceInRight',
					'bounceInUp' => 'bounceInUp',
					'bounceOut' => 'bounceOut',
					'bounceOutDown' => 'bounceOutDown',
					'bounceOutLeft' => 'bounceOutLeft',
					'bounceOutRight' => 'bounceOutRight',
					'bounceOutUp' => 'bounceOutUp',
					'fadeIn' => 'fadeIn',
					'fadeInDown' => 'fadeInDown',
					'fadeInDownBig' => 'fadeInDownBig',
					'fadeInLeft' => 'fadeInLeft',
					'fadeInLeftBig' => 'fadeInLeftBig',
					'fadeInRight' => 'fadeInRight',
					'fadeInRightBig' => 'fadeInRightBig',
					'fadeInUp' => 'fadeInUp',
					'fadeInUpBig' => 'fadeInUpBig',
					'flip' => 'flip',
					'flipInX' => 'flipInX',
					'flipInY' => 'flipInY',				
					'lightSpeedIn' => 'lightSpeedIn',
					'rotateIn' => 'rotateIn',
					'rotateInDownLeft' => 'rotateInDownLeft',
					'rotateInDownRight' => 'rotateInDownRight',
					'rotateInUpLeft' => 'rotateInUpLeft',
					'rotateInUpRight' => 'rotateInUpRight',
					'slideInDown' => 'slideInDown',
					'slideInLeft' => 'slideInLeft',
					'slideInRight' => 'slideInRight'
				)
         ),	
		'heading' => array(
			'std' => '',
			'type' => 'text',
			'label' => __('Heading', 'secretlang'),
			'desc' => __('', 'secretlang')
		),         				
		'content' => array(
			'std' => 'Contents/Shortcodes',
			'type' => 'textarea',
			'label' => __('Column Content/ Use Wp Editor', 'secretlang'),
			'desc' => __('', 'secretlang'),
		)

	)
);
/* Address Block --- */
//customclass
$zilla_shortcodes['address_block'] = array(
	'title' => __('Address Block', 'secretlang'),
	'id' => 'secretlang-address_block-shortcode',
	'template' => '[address_block {{attributes}}] {{content}} [/address_block]',
	'params' => array(
		'phone' => array(
			'std' => '',
			'type' => 'text',
			'label' => __('Phone', 'secretlang'),
			'desc' => __('Optional', 'secretlang')
		),
		'email' => array(
			'std' => '',
			'type' => 'text',
			'label' => __('Email', 'secretlang'),
			'desc' => __('Optional', 'secretlang')
		),						
		'content' => array(
			'std' => 'Contents/Shortcodes',
			'type' => 'textarea',
			'label' => __('Section Content', 'secretlang'),
			'desc' => __('Its a wrapper. Add more conetnts manually', 'secretlang'),
		)

	)
);




/* HOME Carousel BG image --- */
// small
// heading
// sub
// bg
// fx
$zilla_shortcodes['slider_wrap'] = array(
    'title' => __('Image Carousel', 'secretlang'),
    'id' => 'secretlang-slider_wrap-shortcode',
    'template' => '[slider_wrap] {{child_shortcode}} [/slider_wrap]',
    'notes' => __('Click \'Add Item\' to add a new item. Drag and drop to reorder items.', 'secretlang'),
    'params' => array(),
    'child_shortcode' => array(
        'params' => array(

            'img' => array(
                'std' => '',
                'type' => 'text',
                'label' => __('Image', 'secretlang'),
                'desc' => __(' Absolute Path to Image', 'secretlang')
            ),
		 
		),
        'template' => '[slide {{attributes}}]',
        'clone_button' => __('Add Item', 'secretlang')		                                                     
      )

);




/* HOME Slider --- */
// image
// hstyle
// gradient
$zilla_shortcodes['home_slider'] = array(
    'title' => __('Hero Slider BG Image', 'secretlang'),
    'id' => 'secretlang-home_slider-shortcode',
    'template' => '[home_slider] {{child_shortcode}} [/home_slider]',
    'notes' => __('Click \'Add Item\' to add a new. Drag and drop to reorder items.', 'secretlang'),
    'params' => array(),
    'child_shortcode' => array(
        'params' => array(
            'bg_image' => array(
                'std' => '',
                'type' => 'text',
                'label' => __('Image', 'secretlang'),
                'desc' => __('Absolute Path to Image', 'secretlang'),
            ),
		    'style' => array(
			'type' => 'select',
			'label' => __('Slide Style', 'secretlang'),
			'desc' => __('', 'secretlang'),
			'options' => array(
			    '1' => '1',
			    '2' => '2',
			    )
			),
			'title' => array(
				'std' => '',
				'type' => 'text',
				'label' => __('Title', 'secretlang'),
				'desc' => __('', 'secretlang'),
			),
			'sub' => array(
				'std' => '',
				'type' => 'text',
				'label' => __('Sub Heading', 'secretlang'),
				'desc' => __('', 'secretlang'),
			),
			'color' => array(
				'std' => '#FFF',
				'type' => 'text',
				'label' => __('Text Color', 'secretlang'),
				'desc' => __('', 'secretlang'),
			),
			'link' => array(
				'std' => '#',
				'type' => 'text',
				'label' => __('Down Arrow Link', 'secretlang'),
				'desc' => __('', 'secretlang'),
			),															
			'content' => array(
				'std' => 'Contents',
				'type' => 'textarea',
				'label' => __('', 'secretlang'),
				'desc' => __('', 'secretlang'),
			)		                                                       
        ),
        'template' => '[slider_item {{attributes}}] {{content}} [/slider_item]',
        'clone_button' => __('Add Item', 'secretlang')
    )
);

/* HOME Slider --- */
// title
// sub
// button
// link
// color
$zilla_shortcodes['hc_wrapper'] = array(
    'title' => __('Hero Text Carousel', 'secretlang'),
    'id' => 'secretlang-hc_wrapper-shortcode',
    'template' => '[hc_wrapper] {{child_shortcode}} [/hc_wrapper]',
    'notes' => __('Click \'Add Item\' to add a new. Drag and drop to reorder items.', 'secretlang'),
    'params' => array(),
    'child_shortcode' => array(
        'params' => array(
            'color' => array(
                'std' => '#FFFFFF',
                'type' => 'text',
                'label' => __('Text Color', 'secretlang'),
                'desc' => __('Use HEX code', 'secretlang')
            ),    
		    'title' => array(
                'std' => '',
                'type' => 'text',
                'label' => __('Heading', 'secretlang'),
                'desc' => __('', 'secretlang')
            ),    
		    'sub' => array(
                'std' => '',
                'type' => 'text',
                'label' => __('Sub Heading', 'secretlang'),
                'desc' => __('', 'secretlang')
            ),
		    'style' => array(
			'type' => 'select',
			'label' => __('Slide Style', 'secretlang'),
			'desc' => __('', 'secretlang'),
			'options' => array(
			    '1' => '1',
			    '2' => '2')
			),
		    'link' => array(
                'std' => '',
                'type' => 'text',
                'label' => __('Button Link', 'secretlang'),
                'desc' => __('', 'secretlang')
            ),                                                                    
        ),
        'template' => '[hc_item_s1 {{attributes}}] {{content}} [/hc_item_s1]',
        'clone_button' => __('Add Item', 'secretlang')
    )
);



/* About Type --- */
// mode
// categories
$zilla_shortcodes['portfolio'] = array(
	'title' => __('Portfolio', 'secretlang'),
	'id' => 'secretlang-portfolio-shortcode',
	'template' => '[portfolio]',
	'params' => array()
);




/* HOME Carousel BG image --- */
// name
// designation
// photo
// twitter
// facebook
// behance
// linkedin
// dribbble
// flickr
$zilla_shortcodes['teamwrap'] = array(
    'title' => __('Team', 'secretlang'),
    'id' => 'secretlang-teamwrap-shortcode',
    'template' => '[teamwrap] {{child_shortcode}} [/teamwrap]',
    'notes' => __('Click \'Add Member\' to add a new member setup. Drag and drop to reorder.', 'secretlang'),
    'params' => array(),
    'child_shortcode' => array(
        'params' => array(
            'name' => array(
                'std' => '',
                'type' => 'text',
                'label' => __('Member Name', 'secretlang'),
                'desc' => __('', 'secretlang'),
            ),
            'designation' => array(
                'std' => '',
                'type' => 'text',
                'label' => __('Designation', 'secretlang'),
                'desc' => __('', 'secretlang')
            ),
            'photo' => array(
                'std' => '',
                'type' => 'text',
                'label' => __('Photo', 'secretlang'),
                'desc' => __('Use absolute path to Image', 'secretlang')
            ),
            'twitter' => array(
                'std' => '',
                'type' => 'text',
                'label' => __('Twitter', 'secretlang'),
                'desc' => __('Optional', 'secretlang')
            ), 
            'facebook' => array(
                'std' => '',
                'type' => 'text',
                'label' => __('facebook', 'secretlang'),
                'desc' => __('Optional', 'secretlang')
            ), 
            'plus' => array(
                'std' => '',
                'type' => 'text',
                'label' => __('GPlus', 'secretlang'),
                'desc' => __('Optional', 'secretlang')
            ), 
            'email' => array(
                'std' => '',
                'type' => 'text',
                'label' => __('email', 'secretlang'),
                'desc' => __('Optional', 'secretlang')
            ),
                                   
		),                                                     
        'template' => '[team_member {{attributes}}] {{content}} [/team_member]',
        'clone_button' => __('Add Member', 'secretlang')
      )
);




/* SEC - Service Wrap--- */

$zilla_shortcodes['services_wrap'] = array(
    'title' => __('Services Block', 'secretlang'),
    'id' => 'secretlang-services_wrap-shortcode',
    'template' => '[services_wrap] {{child_shortcode}} [/services_wrap]',
    'notes' => __('Click \'Add Member\' to add a new member setup. Drag and drop to reorder.', 'secretlang'),
    'params' => array(),
    'child_shortcode' => array(
        'params' => array(
            'title' => array(
                'std' => '',
                'type' => 'text',
                'label' => __('Title', 'secretlang'),
                'desc' => __('', 'secretlang'),
            ),
			'icon' => array(
				'std' => '',
				'type' => 'text',
				'label' => __('Icon', 'secretlang'),
				'desc' => __('Absolute link to Icon Image file', 'secretlang')
			),	            
            'link' => array(
                'std' => '',
                'type' => 'text',
                'label' => __('Link', 'secretlang'),
                'desc' => __('', 'secretlang')
            ),
            'label' => array(
                'std' => '',
                'type' => 'text',
                'label' => __('Link', 'secretlang'),
                'desc' => __('', 'secretlang')
            ),            
			'fx' => array(
					'type' => 'select',
					'label' => __('Apparance Animation', 'secretlang'),
					'desc' => __('', 'secretlang'),
					'options' => array(
						'' => 'None',
						'bounce' => 'bounce',
						'flash' => 'flash',
						'pulse' => 'pulse',
						'shake' => 'shake',
						'swing' => 'swing',
						'tada' => 'tada',
						'wobble' => 'wobble',
						'bounceIn' => 'bounceIn',
						'bounceInDown' => 'bounceInDown',
						'bounceInLeft' => 'bounceInLeft',
						'bounceInRight' => 'bounceInRight',
						'bounceInUp' => 'bounceInUp',
						'bounceOut' => 'bounceOut',
						'bounceOutDown' => 'bounceOutDown',
						'bounceOutLeft' => 'bounceOutLeft',
						'bounceOutRight' => 'bounceOutRight',
						'bounceOutUp' => 'bounceOutUp',
						'fadeIn' => 'fadeIn',
						'fadeInDown' => 'fadeInDown',
						'fadeInDownBig' => 'fadeInDownBig',
						'fadeInLeft' => 'fadeInLeft',
						'fadeInLeftBig' => 'fadeInLeftBig',
						'fadeInRight' => 'fadeInRight',
						'fadeInRightBig' => 'fadeInRightBig',
						'fadeInUp' => 'fadeInUp',
						'fadeInUpBig' => 'fadeInUpBig',
						'flip' => 'flip',
						'flipInX' => 'flipInX',
						'flipInY' => 'flipInY',				
						'lightSpeedIn' => 'lightSpeedIn',
						'rotateIn' => 'rotateIn',
						'rotateInDownLeft' => 'rotateInDownLeft',
						'rotateInDownRight' => 'rotateInDownRight',
						'rotateInUpLeft' => 'rotateInUpLeft',
						'rotateInUpRight' => 'rotateInUpRight',
						'slideInDown' => 'slideInDown',
						'slideInLeft' => 'slideInLeft',
						'slideInRight' => 'slideInRight'
					)
	         ),				
			'content' => array(
				'std' => 'Contents/Shortcodes',
				'type' => 'textarea',
				'label' => __('Section Content', 'secretlang'),
				'desc' => __('Its a wrapper. Add more conetnts manually', 'secretlang'),
			)                                  
		),                                                     
        'template' => '[service {{attributes}}] {{content}} [/service]',
        'clone_button' => __('Add Service', 'secretlang')
      )
);



/* Price Table--- */
// title-
// price-
// basis-
// suffix-
// link-
// label-
// pos
// fx
$zilla_shortcodes['price_table'] = array(
    'title' => __('Price Table', 'secretlang'),
    'id' => 'secretlang-price_table-shortcode',
    'template' => '[price_table {{attributes}}] {{content}} [/price_table]',
    'notes' => __('Click \'Add Spec\' to add a new data. Drag and drop to reorder.', 'secretlang'),  
    'params' => array(
			'title' => array(
				'std' => 'Title',
				'type' => 'text',
				'label' => __('Table Title', 'secretlang'),
				'desc' => __('Spec\'s heading', 'secretlang'),
			),				
			'price' => array(
				'std' => '$20',
				'type' => 'text',
				'label' => __('Price', 'secretlang'),
				'desc' => __('', 'secretlang'),
			), 
			'basis' => array(
				'std' => 'per month',
				'type' => 'text',
				'label' => __('Basis', 'secretlang'),
				'desc' => __('Ex: Per month', 'secretlang'),
			), 
			'label' => array(
				'std' => 'Order Now',
				'type' => 'text',
				'label' => __('Button Label', 'secretlang'),
				'desc' => __('', 'secretlang'),
			),			
			'link' => array(
				'std' => '#',
				'type' => 'text',
				'label' => __('Button Link', 'secretlang'),
				'desc' => __('', 'secretlang'),
			),
			'content' => array(
				'std' => 'Contents/Shortcodes',
				'type' => 'textarea',
				'label' => __('Section Content', 'secretlang'),
				'desc' => __('', 'secretlang'),
			), 
			'width' => array(
				'type' => 'select',
				'label' => __('Columns', 'secretlang'),
				'desc' => __('Bootstrap Columns', 'secretlang'),
				'options' => array(
					'3' => '3',
					'1' => '1',
					'2' => '3',
					'4' => '4',
					'5' => '5',	
					'6' => '6',																	
				)
			),				    																	    	
		    'fx' => array(
				'type' => 'select',
				'label' => __('Apparance Animation', 'secretlang'),
				'desc' => __('', 'secretlang'),
				'options' => array(
					'' => 'None',
					'bounce' => 'bounce',
					'flash' => 'flash',
					'pulse' => 'pulse',
					'shake' => 'shake',
					'swing' => 'swing',
					'tada' => 'tada',
					'wobble' => 'wobble',
					'bounceIn' => 'bounceIn',
					'bounceInDown' => 'bounceInDown',
					'bounceInLeft' => 'bounceInLeft',
					'bounceInRight' => 'bounceInRight',
					'bounceInUp' => 'bounceInUp',
					'bounceOut' => 'bounceOut',
					'bounceOutDown' => 'bounceOutDown',
					'bounceOutLeft' => 'bounceOutLeft',
					'bounceOutRight' => 'bounceOutRight',
					'bounceOutUp' => 'bounceOutUp',
					'fadeIn' => 'fadeIn',
					'fadeInDown' => 'fadeInDown',
					'fadeInDownBig' => 'fadeInDownBig',
					'fadeInLeft' => 'fadeInLeft',
					'fadeInLeftBig' => 'fadeInLeftBig',
					'fadeInRight' => 'fadeInRight',
					'fadeInRightBig' => 'fadeInRightBig',
					'fadeInUp' => 'fadeInUp',
					'fadeInUpBig' => 'fadeInUpBig',
					'flip' => 'flip',
					'flipInX' => 'flipInX',
					'flipInY' => 'flipInY',				
					'lightSpeedIn' => 'lightSpeedIn',
					'rotateIn' => 'rotateIn',
					'rotateInDownLeft' => 'rotateInDownLeft',
					'rotateInDownRight' => 'rotateInDownRight',
					'rotateInUpLeft' => 'rotateInUpLeft',
					'rotateInUpRight' => 'rotateInUpRight',
					'slideInDown' => 'slideInDown',
					'slideInLeft' => 'slideInLeft',
					'slideInRight' => 'slideInRight'
				)
         ),		
    	)
);

/* testimonial Table--- */
// photo
// name
// desig
$zilla_shortcodes['testimonial'] = array(
    'title' => __('Testimonial', 'secretlang'),
    'id' => 'secretlang-testimonial_wrapper-shortcode',
    'template' => '[testimonial_wrapper] {{child_shortcode}} [/testimonial_wrapper]',
    'notes' => __('Click \'Add Testimonial\' to add a new data. Drag and drop to reorder.', 'secretlang'),  
    'params' => array(),
    'child_shortcode' => array(
        'params' => array(	   
            'name' => array(
                'std' => '',
                'type' => 'text',
                'label' => __('Author Name', 'secretlang'),
                'desc' => __('', 'secretlang'),
            ),                       	
            'designation' => array(
                'std' => '',
                'type' => 'text',
                'label' => __('Designation', 'secretlang'),
                'desc' => __('', 'secretlang'),
            ),
            'content' => array(
                'std' => '',
                'type' => 'textarea',
                'label' => __('Testimonial', 'secretlang'),
                'desc' => __('', 'secretlang')
            )
        ),
        'template' => '[testimonial {{attributes}}] {{content}} [/testimonial]',
        'clone_button' => __('Add Testimonial', 'secretlang')
    )    
);





/* CF --- */
// categories
$zilla_shortcodes['contact_form'] = array(
	'title' => __('Contact Form', 'secretlang'),
	'id' => 'secretlang-contact_form-shortcode',
	'notes' => __('Configure through theme options', 'secretlang'),
	'template' => '[contact_form]',
	'params' => array()
);




$zilla_shortcodes['thm_button'] = array(
	'title' => __('Theme Button', 'secretlang'),
	'id' => 'secretlang-thm_button-shortcode',
	'notes' => __('Refer Docs', 'secretlang'),
	'template' => '[thm_button {{attributes}}]',
	'params' => array(			
		'label' => array(
			'std' => '',
			'type' => 'text',
			'label' => __('Button Label', 'secretlang'),
			'desc' => __('', 'secretlang'),
		),
		'link' => array(
			'std' => '#',
			'type' => 'text',
			'label' => __('Link', 'secretlang'),
			'desc' => __('', 'secretlang'),
		),			
	)
);


